document.getElementById("startBtn").onclick = function () {
    window.location.href = "game.html";
};